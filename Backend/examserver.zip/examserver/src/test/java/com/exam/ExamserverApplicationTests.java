package com.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
